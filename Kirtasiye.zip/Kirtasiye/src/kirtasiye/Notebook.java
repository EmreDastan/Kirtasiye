package kirtasiye;

public class Notebook {
	String color = "Kirmizi";
	String islev = "Kalem yardimiyla ustune yazi yazilir ve not tutulur.";
	String fiyat = "15.50 TRY";
}
