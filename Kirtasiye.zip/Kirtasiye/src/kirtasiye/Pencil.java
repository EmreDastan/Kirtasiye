package kirtasiye;

public class Pencil {
	String color = "Yesil";
	String islev = "Silgi ile silinebilir yazi yazar.";
	String fiyat = "3.99 TRY";
}
