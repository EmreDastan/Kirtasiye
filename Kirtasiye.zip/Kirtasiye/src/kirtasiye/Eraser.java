package kirtasiye;

public class Eraser {
	String color = "Beyaz";
	String islev = "yazilanlari siler.";
	String fiyat = "6.99 TRY";
}
