package kirtasiye;

public class PencilCase {
	String color = "Mavi";
	String islev = "Malzemeleri icinde tutar. (kalem, silgi...)";
	String fiyat = "20 TRY";
}
