package kirtasiye;

public class Pen {
	String color = "Black";
	String islev = "Silgi ile silinmeyen yazi yazar.";
	String fiyat = "24.99 TRY";
	String ozel = "Marka sahibi ozel bir dolma kalemdir.";
}
