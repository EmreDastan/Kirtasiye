package kirtasiye;

import java.util.ArrayList;
import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		ArrayList<String> urunler = new ArrayList<String>();
		Scanner scan = new Scanner(System.in);
		System.out.println("Urunler : ");
		urunler.add("Silgi");
		urunler.add("Defter");
		urunler.add("Dolma Kalem");
		urunler.add("Kursun Kalem");
		urunler.add("Kalem Kutusu");
		urunler.add("KalemTras");
			System.out.println(urunler);
		System.out.println("Hangisini almak istersiniz ?\n[Ismini Yazin.]");
		String q1 = scan.nextLine();
			if (q1.equalsIgnoreCase(urunler.get(0))) {
				// Eraser class
				Eraser eraser = new Eraser();
				System.out.println("Renk : " + eraser.color);
				System.out.println("Islev : " + eraser.islev);
				System.out.println("Fiyat : " + eraser.fiyat);
			}
			else if (q1.equalsIgnoreCase(urunler.get(1))) {
				// Notebook class
				Notebook notebook = new Notebook();
				System.out.println("Renk : " + notebook.color);
				System.out.println("Islev : " + notebook.islev);
				System.out.println("Fiyat : " + notebook.fiyat);
				
			}
			else if (q1.equalsIgnoreCase(urunler.get(2))) {
				// Pen class
				Pen pen = new Pen();
				System.out.println("Renk : " + pen.color);
				System.out.println("Islev : " + pen.islev);
				System.out.println("Fiyat : " + pen.fiyat);
				System.out.println("Fiyat : " + pen.ozel);
			}
			else if (q1.equalsIgnoreCase(urunler.get(3))) {
				// Pencil class
				Pencil pencil = new Pencil();
				System.out.println("Renk : " + pencil.color);
				System.out.println("Islev : " + pencil.islev);
				System.out.println("Fiyat : " + pencil.fiyat);
			}
			else if (q1.equalsIgnoreCase(urunler.get(4))) {
				// PencilCase class
				PencilCase pencilcase = new PencilCase();
				System.out.println("Renk : " + pencilcase.color);
				System.out.println("Islev : " + pencilcase.islev);
				System.out.println("Fiyat : " + pencilcase.fiyat);
			}
			else if (q1.equalsIgnoreCase(urunler.get(5))) {
				// Sharpener class
				Sharpener sharpener = new Sharpener();
				System.out.println("Renk : " + sharpener.color);
				System.out.println("Islev : " + sharpener.islev);
				System.out.println("Fiyat : " + sharpener.fiyat);
			}
			
	}
}
