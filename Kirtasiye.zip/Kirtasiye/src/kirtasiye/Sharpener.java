package kirtasiye;

public class Sharpener {
	String color = "Pembe";
	String islev = "Kursun kalemleri acar.";
	String fiyat = "5 TRY";
}
